// ChildView.h : Schnittstelle der Klasse CChildView
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_CHILDVIEW_H__E8FFD92E_C82E_4479_B21A_7AE2DE9938E1__INCLUDED_)
#define AFX_CHILDVIEW_H__E8FFD92E_C82E_4479_B21A_7AE2DE9938E1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/////////////////////////////////////////////////////////////////////////////
// CChildView-Fenster

class CChildView : public CWnd
{
// Konstruktion
public:
	CChildView();

// Attribute
public:

// Operationen
public:

// �berladungen
	// Vom Klassen-Assistenten erstellte virtuelle Funktions�berladungen
	//{{AFX_VIRTUAL(CChildView)
	protected:
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	//}}AFX_VIRTUAL

// Implementierung
public:
	void SetCustomMenu (BOOL bMode);
	BOOL IsCustomMenu ();
	void SetView (UINT nView);
	UINT GetView ();
	virtual ~CChildView();

	// Generierte Funktionen f�r die Nachrichtentabellen
protected:
	//{{AFX_MSG(CChildView)
	afx_msg void OnPaint();
	afx_msg void OnSize(UINT nType, int cx, int cy);
	afx_msg int OnCreate(LPCREATESTRUCT lpCreateStruct);
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
private:
	BOOL bCustomMenu;
	afx_msg void OnRClickFileList(NMHDR* pNMHDR, LRESULT* pResult);
	afx_msg void OnDblclkFileList (NMHDR* pNMHDR, LRESULT* pResult);
	void MakeAttributeString (DWORD dwAttributes, TCHAR * pszString);
	afx_msg void OnGetDispInfoFileList (NMHDR* pNMHDR, LRESULT* pResult);
	OBJECT_DATA * pod;
	void ClearObjectData (OBJECT_DATA * pod);
	void AddBackSlash (CString &strPath);
	void ReadFolder (CString strPath);
	HIMAGELIST GetSystemImageList (BOOL bLarge = FALSE);
	CListCtrl m_FileList;
};

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorherigen Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_CHILDVIEW_H__E8FFD92E_C82E_4479_B21A_7AE2DE9938E1__INCLUDED_)
