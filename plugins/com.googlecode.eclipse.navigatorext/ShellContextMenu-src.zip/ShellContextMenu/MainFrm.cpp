// MainFrm.cpp : Implementierung der Klasse CMainFrame
//

#include "stdafx.h"
#include "ShellContextMenu_Demo.h"

#include "MainFrm.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CMainFrame

IMPLEMENT_DYNAMIC(CMainFrame, CFrameWnd)

BEGIN_MESSAGE_MAP(CMainFrame, CFrameWnd)
	//{{AFX_MSG_MAP(CMainFrame)
	ON_WM_CREATE()
	ON_WM_SETFOCUS()
	ON_UPDATE_COMMAND_UI(IDM_VIEW_CUSTOMMENU, OnUpdateViewCustommenu)
	ON_COMMAND(IDM_VIEW_CUSTOMMENU, OnViewCustommenu)
	//}}AFX_MSG_MAP
	ON_UPDATE_COMMAND_UI_RANGE (IDM_VIEW_LARGEICONS, IDM_VIEW_REPORT, OnUpdateView)
	
	ON_COMMAND_RANGE (IDM_VIEW_LARGEICONS, IDM_VIEW_REPORT, OnView)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Konstruktion/Zerst�rung

CMainFrame::CMainFrame()
{
	// ZU ERLEDIGEN: Hier Code zur Member-Initialisierung einf�gen
	
}

CMainFrame::~CMainFrame()
{
}

int CMainFrame::OnCreate(LPCREATESTRUCT lpCreateStruct)
{
	if (CFrameWnd::OnCreate(lpCreateStruct) == -1)
		return -1;
	// create a view to occupy the client area of the frame
	if (!m_wndView.Create(NULL, NULL, AFX_WS_DEFAULT_VIEW,
		CRect(0, 0, 0, 0), this, AFX_IDW_PANE_FIRST, NULL))
	{
		TRACE0("Failed to create view window\n");
		return -1;
	}

	return 0;
}

BOOL CMainFrame::PreCreateWindow(CREATESTRUCT& cs)
{
	if( !CFrameWnd::PreCreateWindow(cs) )
		return FALSE;
	// ZU ERLEDIGEN: �ndern Sie hier die Fensterklasse oder das Erscheinungsbild, indem Sie
	//  CREATESTRUCT cs modifizieren.

	cs.dwExStyle &= ~WS_EX_CLIENTEDGE;
	cs.lpszClass = AfxRegisterWndClass(0);
	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Diagnose

#ifdef _DEBUG
void CMainFrame::AssertValid() const
{
	CFrameWnd::AssertValid();
}

void CMainFrame::Dump(CDumpContext& dc) const
{
	CFrameWnd::Dump(dc);
}

#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CMainFrame Nachrichten-Handler
void CMainFrame::OnSetFocus(CWnd* pOldWnd)
{
	// Fokus an das Ansichtfenster weitergeben
	m_wndView.SetFocus();
}

BOOL CMainFrame::OnCmdMsg(UINT nID, int nCode, void* pExtra, AFX_CMDHANDLERINFO* pHandlerInfo)
{
	// Ansichtfenster erh�lt ersten Eindruck vom Befehl
	if (m_wndView.OnCmdMsg(nID, nCode, pExtra, pHandlerInfo))
		return TRUE;

	// andernfalls die Standardbehandlung durchf�hren
	return CFrameWnd::OnCmdMsg(nID, nCode, pExtra, pHandlerInfo);
}


void CMainFrame::OnUpdateView(CCmdUI *pCmdUI)
{
	pCmdUI->Enable (TRUE);
	if (m_wndView.GetView () == pCmdUI->m_nID)
		pCmdUI->SetCheck (MF_CHECKED);
	else
		pCmdUI->SetCheck (MF_UNCHECKED);
}

void CMainFrame::OnView(UINT nID)
{
	m_wndView.SetView (nID - IDM_VIEW_LARGEICONS);
}

void CMainFrame::OnUpdateViewCustommenu(CCmdUI* pCmdUI) 
{
	// TODO: Code f�r die Befehlsbehandlungsroutine zum Aktualisieren der Benutzeroberfl�che hier einf�gen
	pCmdUI->Enable (BST_CHECKED);
	if (m_wndView.IsCustomMenu ())
		pCmdUI->SetCheck (MF_CHECKED);
	else
		pCmdUI->SetCheck (MF_UNCHECKED);
}

void CMainFrame::OnViewCustommenu() 
{
	// TODO: Code f�r Befehlsbehandlungsroutine hier einf�gen
	if (m_wndView.IsCustomMenu ())
		m_wndView.SetCustomMenu (FALSE);
	else
		m_wndView.SetCustomMenu (TRUE);
}
