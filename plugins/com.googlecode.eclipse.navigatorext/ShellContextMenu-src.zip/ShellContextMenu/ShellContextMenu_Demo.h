// ShellContextMenu_Demo.h : Haupt-Header-Datei f�r die Anwendung SHELLCONTEXTMENU_DEMO
//

#if !defined(AFX_SHELLCONTEXTMENU_DEMO_H__44B2C689_3B9C_417D_8278_00B103CA1B75__INCLUDED_)
#define AFX_SHELLCONTEXTMENU_DEMO_H__44B2C689_3B9C_417D_8278_00B103CA1B75__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // Hauptsymbole

/////////////////////////////////////////////////////////////////////////////
// CShellContextMenu_DemoApp:
// Siehe ShellContextMenu_Demo.cpp f�r die Implementierung dieser Klasse
//

class CShellContextMenu_DemoApp : public CWinApp
{
public:
	CShellContextMenu_DemoApp();

// �berladungen
	// Vom Klassenassistenten generierte �berladungen virtueller Funktionen
	//{{AFX_VIRTUAL(CShellContextMenu_DemoApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementierung

public:
	//{{AFX_MSG(CShellContextMenu_DemoApp)
	afx_msg void OnAppAbout();
		// HINWEIS - An dieser Stelle werden Member-Funktionen vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ f�gt unmittelbar vor der vorhergehenden Zeile zus�tzliche Deklarationen ein.

#endif // !defined(AFX_SHELLCONTEXTMENU_DEMO_H__44B2C689_3B9C_417D_8278_00B103CA1B75__INCLUDED_)
