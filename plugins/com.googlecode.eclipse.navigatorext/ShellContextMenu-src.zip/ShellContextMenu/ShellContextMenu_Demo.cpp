// ShellContextMenu_Demo.cpp : Legt das Klassenverhalten f�r die Anwendung fest.
//

#include "stdafx.h"
#include <iostream>
using namespace std;
#include "ShellContextMenu.h"
#include "ShellContextMenu_Demo.h"
#include "MainFrm.h"
#include "cmdlineargs.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CShellContextMenu_DemoApp

BEGIN_MESSAGE_MAP(CShellContextMenu_DemoApp, CWinApp)
	//{{AFX_MSG_MAP(CShellContextMenu_DemoApp)
	ON_COMMAND(ID_APP_ABOUT, OnAppAbout)
		// HINWEIS - Hier werden Mapping-Makros vom Klassen-Assistenten eingef�gt und entfernt.
		//    Innerhalb dieser generierten Quelltextabschnitte NICHTS VER�NDERN!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CShellContextMenu_DemoApp Konstruktion

CShellContextMenu_DemoApp::CShellContextMenu_DemoApp()
{
	// ZU ERLEDIGEN: Hier Code zur Konstruktion einf�gen
	// Alle wichtigen Initialisierungen in InitInstance platzieren
}

/////////////////////////////////////////////////////////////////////////////
// Das einzige CShellContextMenu_DemoApp-Objekt

CShellContextMenu_DemoApp theApp;

// After the user has selected an item from the context menu,
// wait deferredExitTimeout milliseconds, then exit application.
// NOTE: User might still have the file properties dialog open.
//       But I don't know how to get notified when user clicks OK/Cancel...
int deferredExitTimeout;
UINT DeferredExit(LPVOID pParam)
{
	cout << "exiting in " << deferredExitTimeout << " ms..." << endl << flush;
	Sleep(deferredExitTimeout);
	AfxGetThread()->ExitInstance();
	exit(0);
	return 0; 
}

/////////////////////////////////////////////////////////////////////////////
// CShellContextMenu_DemoApp Initialisierung

BOOL CShellContextMenu_DemoApp::InitInstance()
{
	// Open new console window (otherwise console output is not displayed)
	// NOTE: cygwin bash displays output even with these lines commented
	//AllocConsole();
	//freopen("CON", "wt", stdout);

	// Standardinitialisierung
	// Wenn Sie diese Funktionen nicht nutzen und die Gr��e Ihrer fertigen 
	//  ausf�hrbaren Datei reduzieren wollen, sollten Sie die nachfolgenden
	//  spezifischen Initialisierungsroutinen, die Sie nicht ben�tigen, entfernen.

#ifdef _AFXDLL
	Enable3dControls();			// Diese Funktion bei Verwendung von MFC in gemeinsam genutzten DLLs aufrufen
#else
	Enable3dControlsStatic();	// Diese Funktion bei statischen MFC-Anbindungen aufrufen
#endif

	// �ndern des Registrierungsschl�ssels, unter dem unsere Einstellungen gespeichert sind.
	// ZU ERLEDIGEN: Sie sollten dieser Zeichenfolge einen geeigneten Inhalt geben
	// wie z.B. den Namen Ihrer Firma oder Organisation.
	// Initialize OLE 2.0 libraries
	if (!AfxOleInit())
	{
		AfxMessageBox(TEXT ("AfxOleInit Error!"));
		return FALSE;
	}
	SetRegistryKey(_T("Local AppWizard-Generated Applications"));

	// Dieser Code erstellt ein neues Rahmenfensterobjekt und setzt dies
	// dann als das Hauptfensterobjekt der Anwendung, um das Hauptfenster zu erstellen.

	CMainFrame* pFrame = new CMainFrame;
	m_pMainWnd = pFrame;

	// Rahmen mit Ressourcen erstellen und laden
	pFrame->LoadFrame(IDR_MAINFRAME,
		WS_OVERLAPPEDWINDOW | FWS_ADDTOTITLE, NULL,
		NULL);

	// Don't show entry in taskbar
	// http://support.dundas.com/Articles/ArticleBody.asp?ArticleID=579
	pFrame->ModifyStyleEx(0, WS_EX_TOOLWINDOW); 

	// Das einzige Fenster ist initialisiert und kann jetzt angezeigt und aktualisiert werden.

	// detect mouse position
	CPoint pt;
    GetCursorPos(&pt);

	// don't show explorer window
	pFrame->MoveWindow(pt.x, pt.y, 0, 0);
	pFrame->MoveWindow(-1000, -1000, 0, 0);
	pFrame->ShowWindow(SW_SHOW);
	pFrame->UpdateWindow();
	// Turning wait cursor off here makes cursor completely invisible!?
	//AfxGetApp()->DoWaitCursor(-1);

	// read command line arguments
	CStringArray files;
	CmdLineArgs args;
	for (int i = 1; i < args.size(); i++)
	{
		if (i == 1)
		{
			// first argument is deferredExitTimeout
			deferredExitTimeout = atoi(args[i]);
			cout << "deferredExitTimeout=" << deferredExitTimeout << endl << flush;
		}
		else
		{
			files.Add(args[i]);
			cout << "arg=" << args[i] << endl << flush;
		}
	}

	CShellContextMenu scm;        
	try
	{
		// NOTE: All files must be in same directory
		scm.SetObjects(files);
		scm.ShowContextMenu(pFrame, pt);
	}
	catch (...)
	{
		MessageBox(NULL, "Usage:\nShellContextMenu <milliseconds> <file | directory> ...", "Error", MB_OK);
		ExitProcess(1);
	}
	// start a timer to close application in some seconds
	AfxBeginThread(DeferredExit, NULL);

	return TRUE;
}

/////////////////////////////////////////////////////////////////////////////
// CShellContextMenu_DemoApp Nachrichten-Handler





/////////////////////////////////////////////////////////////////////////////
// CAboutDlg-Dialog f�r Info �ber Anwendung

class CAboutDlg : public CDialog
{
public:
	CAboutDlg();

// Dialogdaten
	//{{AFX_DATA(CAboutDlg)
	enum { IDD = IDD_ABOUTBOX };
	//}}AFX_DATA

	// �berladungen f�r virtuelle Funktionen, die vom Anwendungs-Assistenten erzeugt wurden
	//{{AFX_VIRTUAL(CAboutDlg)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV-Unterst�tzung
	//}}AFX_VIRTUAL

// Implementierung
protected:
	//{{AFX_MSG(CAboutDlg)
		// Keine Nachrichten-Handler
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

CAboutDlg::CAboutDlg() : CDialog(CAboutDlg::IDD)
{
	//{{AFX_DATA_INIT(CAboutDlg)
	//}}AFX_DATA_INIT
}

void CAboutDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CAboutDlg)
	//}}AFX_DATA_MAP
}

BEGIN_MESSAGE_MAP(CAboutDlg, CDialog)
	//{{AFX_MSG_MAP(CAboutDlg)
		// Keine Nachrichten-Handler
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

// Anwendungsbefehl zum Ausf�hren des Dialogfelds
void CShellContextMenu_DemoApp::OnAppAbout()
{
	CAboutDlg aboutDlg;
	aboutDlg.DoModal();
}

/////////////////////////////////////////////////////////////////////////////
// CShellContextMenu_DemoApp-Nachrichtenbehandlungsroutinen

