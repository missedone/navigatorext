// ChildView.cpp : Implementatierung der Klasse CChildView
//

#include "stdafx.h"
#include "ShellContextMenu_Demo.h"
#include "ChildView.h"

// CShellContextMenu
#include "ShellContextMenu.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CChildView

#define IDC_FILELIST	101	// ID if listview
#define PREALLOCATE_SIZE 2500


CChildView::CChildView()
{
	pod = NULL;
	bCustomMenu = FALSE;
}

CChildView::~CChildView()
{
	ClearObjectData (pod);
}


BEGIN_MESSAGE_MAP(CChildView,CWnd )
	//{{AFX_MSG_MAP(CChildView)
	ON_WM_PAINT()
	ON_WM_SIZE()
	ON_WM_CREATE()
	//}}AFX_MSG_MAP
	ON_NOTIFY (LVN_GETDISPINFO, IDC_FILELIST, OnGetDispInfoFileList)
	ON_NOTIFY (NM_DBLCLK, IDC_FILELIST, OnDblclkFileList)
	ON_NOTIFY(NM_RCLICK, IDC_FILELIST, OnRClickFileList)
END_MESSAGE_MAP()


/////////////////////////////////////////////////////////////////////////////
// Nachrichtenbehandlungsroutinen von CChildView

BOOL CChildView::PreCreateWindow(CREATESTRUCT& cs) 
{
	if (!CWnd::PreCreateWindow(cs))
		return FALSE;

	//cs.dwExStyle |= WS_EX_CLIENTEDGE;
	cs.style &= ~WS_BORDER;
	cs.lpszClass = AfxRegisterWndClass(CS_DBLCLKS, 
		::LoadCursor(NULL, IDC_ARROW), GetSysColorBrush (COLOR_3DFACE), NULL);

	return TRUE;
}

void CChildView::OnPaint() 
{
	CPaintDC dc(this); // Ger�tekontext zum Zeichnen
	
	// ZU ERLEDIGEN: F�gen Sie hier Ihren Code f�r die Nachrichtenbehandlung hinzu
	
	// Rufen Sie nicht CWnd::OnPaint() f�r Nachrichten zum Zeichnen auf
}


void CChildView::OnSize(UINT nType, int cx, int cy) 
{
	CWnd ::OnSize(nType, cx, cy);
	
	// TODO: Code f�r die Behandlungsroutine f�r Nachrichten hier einf�gen
	m_FileList.MoveWindow (CRect (0, 0, cx, cy), TRUE);
}

int CChildView::OnCreate(LPCREATESTRUCT lpCreateStruct) 
{
	if (CWnd ::OnCreate(lpCreateStruct) == -1)
		return -1;
	
	// TODO: Speziellen Erstellungscode hier einf�gen
	
	m_FileList.Create (WS_CHILD | WS_VISIBLE | LVS_REPORT | LVS_OWNERDATA | LVS_SHAREIMAGELISTS | LVS_SHOWSELALWAYS, CRect (0, 0, 0, 0), this, IDC_FILELIST);
	m_FileList.ModifyStyleEx (NULL, WS_EX_CLIENTEDGE);
	m_FileList.SetImageList (CImageList::FromHandle (GetSystemImageList (FALSE)), LVSIL_SMALL);
	m_FileList.SetImageList (CImageList::FromHandle (GetSystemImageList (TRUE)), LVSIL_NORMAL);

	m_FileList.InsertColumn (0, TEXT ("Name"), LVCFMT_LEFT, 250, 0);
	m_FileList.InsertColumn (1, TEXT ("Size"), LVCFMT_RIGHT, 80, 1);
	m_FileList.InsertColumn (2, TEXT ("Type"), LVCFMT_LEFT, 250, 2);
	m_FileList.InsertColumn (3, TEXT ("Last Modified"), LVCFMT_LEFT, 130, 3);
	m_FileList.InsertColumn (4, TEXT ("Attributes"), LVCFMT_RIGHT, 100, 4);
	
	ListView_SetExtendedListViewStyleEx (m_FileList.m_hWnd, LVS_EX_FULLROWSELECT, LVS_EX_FULLROWSELECT);
	ReadFolder ((CString) TEXT ("c:\\"));
	return 0;
}

HIMAGELIST CChildView::GetSystemImageList(BOOL bLarge)
{
	SHFILEINFO sfi;

	if (bLarge)
		return (HIMAGELIST) SHGetFileInfo (TEXT ("c:\\"), NULL, &sfi, sizeof (sfi), SHGFI_SYSICONINDEX | SHGFI_LARGEICON);
	else
		return (HIMAGELIST) SHGetFileInfo (TEXT ("c:\\"), NULL, &sfi, sizeof (sfi), SHGFI_SYSICONINDEX | SHGFI_SMALLICON);
}

void CChildView::ReadFolder(CString strPath)
{
	WIN32_FIND_DATA wfd = {0};

	AddBackSlash (strPath);
	HANDLE hFind = FindFirstFile (strPath + TEXT ("*.*"), &wfd);
	BOOL bResult = (hFind == INVALID_HANDLE_VALUE) ? FALSE : TRUE;

	m_FileList.SetItemCountEx (0, LVSICF_NOINVALIDATEALL);
	ClearObjectData (pod);
	pod = NULL;

	int iCount = 0;
	int nPathLength = strPath.GetLength () + 1;
	if (strPath.GetLength () > 3)	// not root; add parent folder
	{
		pod = (OBJECT_DATA *) realloc (pod, PREALLOCATE_SIZE * sizeof (OBJECT_DATA));
		TCHAR * pszPath = (TCHAR *) calloc (strPath.GetLength () + 1, sizeof (TCHAR));
		_tcscpy (pszPath, strPath);
		pszPath[_tcslen (pszPath) - 1] = '\0';
		for (int i = _tcslen (pszPath) - 1; i >= 0; i--)
		{
			if (pszPath[i] == '\\')
			{
				pszPath[i] = '\0';
				break;
			}
		}
		SHFILEINFO sfi = {0};
		SHGetFileInfo (TEXT ("."), FILE_ATTRIBUTE_DIRECTORY, &sfi, sizeof(SHFILEINFO), SHGFI_USEFILEATTRIBUTES | SHGFI_SYSICONINDEX | SHGFI_OPENICON | SHGFI_TYPENAME);
		pod[0].pszFullPath = (TCHAR *) calloc (_tcslen (pszPath) + 1, sizeof (TCHAR));
		_tcscpy (pod[0].pszFullPath, pszPath);
		_tcscpy (pod[0].szFileName, TEXT (".."));
		pod[0].iIcon = sfi.iIcon;
		_tcscpy (pod[0].szTypeName, sfi.szTypeName);
		pod[0].dwFileAttributes = FILE_ATTRIBUTE_DIRECTORY;
		pod[0].u64FileSize = 0;
		iCount = 1;
		free (pszPath);
	}

	while (bResult)
	{
		if (wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY && wfd.cFileName[0] != '.')	// folder
		{
			if (iCount % PREALLOCATE_SIZE == 0)
				pod = (OBJECT_DATA *) realloc (pod, (iCount + PREALLOCATE_SIZE) * sizeof (OBJECT_DATA));
			pod[iCount].pszFullPath = (TCHAR *) calloc (nPathLength + _tcslen (wfd.cFileName), sizeof (TCHAR));
			_tcscpy (pod[iCount].pszFullPath, strPath);
			_tcscat (pod[iCount].pszFullPath, wfd.cFileName);
			_tcscpy (pod[iCount].szFileName, wfd.cFileName);
			pod[iCount].dwFileAttributes = wfd.dwFileAttributes;
			pod[iCount].u64FileSize = 0;
			pod[iCount].iIcon = -1;	// not retrieves yet
			iCount++;
		}
		bResult = FindNextFile (hFind, &wfd);
	}
	FindClose (hFind);

	// read files
	hFind = FindFirstFile (strPath + TEXT ("*.*"), &wfd);
	bResult = (hFind == INVALID_HANDLE_VALUE) ? FALSE : TRUE;

	while (bResult)
	{
		if (!(wfd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && wfd.cFileName[0] != '.' && wfd.cFileName[0] != '\0')		// no folder or parent folder
		{
			if (iCount % PREALLOCATE_SIZE == 0)
				pod = (OBJECT_DATA *) realloc (pod, (iCount + PREALLOCATE_SIZE) * sizeof (OBJECT_DATA));
			pod[iCount].pszFullPath = (TCHAR *) calloc (nPathLength + _tcslen (wfd.cFileName), sizeof (TCHAR));
			_tcscpy (pod[iCount].pszFullPath, strPath);
			_tcscat (pod[iCount].pszFullPath, wfd.cFileName);
			_tcscpy (pod[iCount].szFileName, wfd.cFileName);
			pod[iCount].dwFileAttributes = wfd.dwFileAttributes;
			pod[iCount].u64FileSize = ((UINT64) wfd.nFileSizeHigh * ((UINT64) MAXDWORD + (UINT64) 1)) + (UINT64) wfd.nFileSizeLow;
			pod[iCount].ftLastModified = wfd.ftLastWriteTime;
			pod[iCount].iIcon = -1;	// not retrieves yet
			iCount++;
		}
		bResult = FindNextFile (hFind, &wfd);
	}
	FindClose (hFind);

	if (iCount)
		pod = (OBJECT_DATA *) realloc (pod, iCount * sizeof (OBJECT_DATA));

	m_FileList.SetItemCountEx (iCount, LVSICF_NOINVALIDATEALL);
}

void CChildView::AddBackSlash(CString &strPath)
{
	int nLength = strPath.GetLength ();
	if (strPath.GetAt (nLength - 1) != '\\')
		strPath += TEXT ("\\");
}

void CChildView::ClearObjectData(OBJECT_DATA *pod)
{
	if (pod == NULL)
		return;

	int iLimit = _msize (pod) / sizeof (OBJECT_DATA);
	for (int x = 0; x < iLimit; x++)
		free (pod[x].pszFullPath);

	free (pod); 
	pod = NULL;

}


void CChildView::OnGetDispInfoFileList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	LV_DISPINFO* pdi = (LV_DISPINFO*)pNMHDR;
	UINT	SHGFI_GETTYPENAME = 0;
	TCHAR * pszBuffer = NULL;
	SHFILEINFO sfi;
	LVITEM * lvItem = &pdi->item;	// for better handling
	
	if (lvItem->mask & LVIF_IMAGE)		// image needed
	{
		if (pod[lvItem->iItem].iIcon == -1)	// icon not retrieved yet
		{
			SHGetFileInfo (pod[lvItem->iItem].pszFullPath, NULL, &sfi, sizeof (sfi), SHGFI_SYSICONINDEX | SHGFI_TYPENAME);
			pod[lvItem->iItem].iIcon = sfi.iIcon;
			_tcscpy (pod[lvItem->iItem].szTypeName, sfi.szTypeName);
		}
		lvItem->iImage = pod[lvItem->iItem].iIcon;
	}

	if (lvItem->mask & LVIF_TEXT)		// test needed
	{
		switch (lvItem->iSubItem)
		{
		case 0:	// Name
			_tcscpy (lvItem->pszText, pod[lvItem->iItem].szFileName);
			break;

		case 1:	// Size
			pszBuffer = (TCHAR *) calloc (32, sizeof (TCHAR));
			StrFormatByteSize64 (pod[lvItem->iItem].u64FileSize, pszBuffer, 32);
			_tcscpy (lvItem->pszText, pszBuffer);
			free (pszBuffer);
			break;

		case 2:	// Type
			if (pod[lvItem->iItem].iIcon == -1)	// icon and typename no retrieved yet
			{
				SHGetFileInfo (pod[lvItem->iItem].pszFullPath, NULL, &sfi, sizeof (sfi), SHGFI_SYSICONINDEX | SHGFI_TYPENAME);
				pod[lvItem->iItem].iIcon = sfi.iIcon;
				_tcscpy (pod[lvItem->iItem].szTypeName, sfi.szTypeName);
			}
			_tcscpy (lvItem->pszText, pod[lvItem->iItem].szTypeName);
			break;

		case 3:	// Last Modified
			if (!(pod[lvItem->iItem].dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) && pod[lvItem->iItem].szFileName[0] != '.') // is file
			{
				CTime Time (pod[lvItem->iItem].ftLastModified);
				Time = pod[lvItem->iItem].ftLastModified;
				CString strTime = Time.Format (TEXT ("%x %X"));
				_tcscpy (lvItem->pszText, strTime);
			}
			break;

		case 4:	// attributes
			pszBuffer = (TCHAR *) calloc (7, sizeof (TCHAR));
			MakeAttributeString (pod[lvItem->iItem].dwFileAttributes, pszBuffer);
			_tcscpy (lvItem->pszText, pszBuffer);
			free (pszBuffer);
			break;
		}
	}
	*pResult = 0;
}

void CChildView::MakeAttributeString(DWORD dwAttributes, TCHAR * pszString)
{
	pszString[0] = '\0';

	if (dwAttributes & FILE_ATTRIBUTE_ARCHIVE)
		_tcscpy (pszString, TEXT ("A"));

	if (dwAttributes & FILE_ATTRIBUTE_HIDDEN)
		_tcscat (pszString, TEXT ("H"));

	if (dwAttributes & FILE_ATTRIBUTE_READONLY)
		_tcscat (pszString, TEXT ("R"));

	if (dwAttributes & FILE_ATTRIBUTE_SYSTEM)
		_tcscat (pszString, TEXT ("S"));
	
	if (dwAttributes & FILE_ATTRIBUTE_COMPRESSED)
		_tcscat (pszString, TEXT ("C"));

	if (dwAttributes & FILE_ATTRIBUTE_ENCRYPTED)
		_tcscat (pszString, TEXT ("E"));
}
void CChildView::OnDblclkFileList (NMHDR* pNMHDR, LRESULT* pResult) 
{
	int iIndex = m_FileList.GetNextItem (-1, LVNI_FOCUSED);

	if (iIndex == -1)
		return;
	
	CString strPath = pod[iIndex].pszFullPath;
	ReadFolder (strPath);
}

UINT CChildView::GetView()
{
	DWORD dwStyles = m_FileList.GetStyle ();// GetWindowLong (m_FileList.GetSafeHwnd (), GWL_STYLE);

	if ((dwStyles & LVS_TYPEMASK) == LVS_ICON)
		return (IDM_VIEW_LARGEICONS);
	else if ((dwStyles & LVS_TYPEMASK) == LVS_SMALLICON)
		return (IDM_VIEW_SMALLICONS);
	else if ((dwStyles & LVS_TYPEMASK) == LVS_LIST)
		return (IDM_VIEW_LIST);
	else //if ((dwStyles & LVS_TYPEMASK) == LVS_REPORT)
		return (IDM_VIEW_REPORT);

	return (IDM_VIEW_LARGEICONS);
}

void CChildView::SetView(UINT nView)
{
	UINT uModes[] = {LVS_ICON, LVS_SMALLICON, LVS_LIST, LVS_REPORT};

	if (nView > 3) nView = 3;

	DWORD dwStyle = m_FileList.GetStyle ();

	// Only set the window style if the view bits have changed. 
	if ((dwStyle & LVS_TYPEMASK) != uModes[nView]) 
		SetWindowLong(m_FileList.m_hWnd, GWL_STYLE, (dwStyle & ~LVS_TYPEMASK) | uModes[nView]);
}

BOOL CChildView::IsCustomMenu()
{
	return (bCustomMenu);
}

void CChildView::SetCustomMenu(BOOL bMode)
{
	bCustomMenu = bMode;
}

void CChildView::OnRClickFileList(NMHDR* pNMHDR, LRESULT* pResult) 
{
	NMITEMACTIVATE * nmia = (NMITEMACTIVATE *) pNMHDR;

	*pResult = 0;
	POSITION pos = m_FileList.GetFirstSelectedItemPosition ();
	if (!pos)
		return;

	CStringArray arrayFiles;
	int nItem = 0;
	while (pos)
	{
		nItem = m_FileList.GetNextSelectedItem (pos);
		arrayFiles.Add (pod[nItem].pszFullPath);
	}
	
	CMenu * pMenu = NULL;
	CShellContextMenu scm;
	scm.SetObjects (arrayFiles);
	if (bCustomMenu)
	{
		pMenu = scm.GetMenu ();	
		CMenu * pMenuView = GetParent ()->GetMenu ()->GetSubMenu (1);	// Menu 'View'
		pMenu->AppendMenu (MF_BYPOSITION | MF_POPUP, (UINT) pMenuView->m_hMenu, TEXT ("Custom Menu"));
		pMenu->AppendMenu (MF_BYPOSITION, MF_SEPARATOR);
		for (int i = IDM_VIEW_LARGEICONS; i <= IDM_VIEW_REPORT; i++)
		{
			if ((int) GetView () == i)
				pMenuView->CheckMenuItem (IDM_VIEW_CUSTOMMENU, MF_CHECKED);
			else
				pMenuView->CheckMenuItem (IDM_VIEW_CUSTOMMENU, MF_UNCHECKED);
		}
		pMenuView->CheckMenuItem (GetView (), MF_CHECKED);
	}
	
	CPoint point (nmia->ptAction);
	m_FileList.ClientToScreen (&point);

	UINT idCommand = scm.ShowContextMenu (this, point);
	if (bCustomMenu)
		pMenu->RemoveMenu (0, MF_BYPOSITION);	// that's necessary, because we directly used the 'View' menu and not a copy
												// therefore CShellContextMenu would delete it
	if (idCommand)
		GetParent()->SendMessage (WM_COMMAND, idCommand, 0);
	
}

